package com.java8;

@FunctionalInterface
interface myName{
	public abstract void show();
	
}

public class lambda  {
	public static void main(String[] args) {
//	myName i=new myName() {
//		
//		@Override
//		public void show() {
//			System.out.println("hello i am first name");
//			
//		}
//	};
//	myName i2=new myName() {
//		
//		@Override
//		public void show() {
//			System.out.println("hello i am second name");
//			
//		}
//	};
//	i.show();
//	i2.show();
		// using our interface using lambda expression..
		myName i=()->{
			System.out.println("i am lambda expression");
		};
		i.show();
		
		// or if there is a only single method
		myName i1=()->System.out.println("i am lambda expression");
		
		i1.show();
	}

}
