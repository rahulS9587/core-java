package com.java8;

public abstract class ThreadDemo {

	public static void main(String[] args) {

		Runnable t = () -> {
			for (int i = 0; i <= 10; i++) {
				System.out.println("the value is: " + i);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		};
		Runnable tt = () -> {
			for (int i = 0; i < 20; i++) {
				System.out.println(i * 2);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		Thread t1 = new Thread(t);
		// t1.setName("hello");
		Thread t2 = new Thread(tt);
		t1.start();
		t2.start();
	}

}
