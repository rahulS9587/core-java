package com.java8;


@FunctionalInterface
interface xyz {
	void switchOn(int x);

//	default void show1() {
//		System.out.println(" default method");
//	}

}

public class practice {
	public  void show() {
		System.out.println(" static method");
	}
	public static void main(String[] args) {
		// example of anonymous class in java
//		xyz obj=new xyz() {
//			public void switchOn() {
//				System.out.println("Hello world");
//			}
//		};
//		obj.switchOn();
		
		// LAMBDA expressions
//		xyz lambda = (int x) ->
//			System.out.println("hello" +x);
//		
//		lambda.switchOn(10);
//		xyz.show();
//		lambda.show1();
		
		//or
//		xyz zz= practice :: show;
//		zz.show();
	}

}
