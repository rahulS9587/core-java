package com.java8;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class MyWindow {
	public static void main(String[] args) {
		
		JFrame frame=new JFrame("My Window");
		frame.setSize(400, 400);
		frame.setLayout(new FlowLayout());
		 
		
		
		// create button 
		JButton button=new JButton("click");
//		button.addActionListener(new ActionListener() {
//			
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				System.out.println("Button click");
//				JOptionPane.showMessageDialog(null, "Button clicked successfully");
//				
//				
//				
//				
//				
//			}
	//	});
		
		
		// using lambda expression
		
		
		button.addActionListener(e->{
			System.out.println("Button click");
			JOptionPane.showMessageDialog(null, "Button clicked successfully");
	
			});
		
			
			
			
				
			
		
		frame.add(button);
		
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
	}

}
