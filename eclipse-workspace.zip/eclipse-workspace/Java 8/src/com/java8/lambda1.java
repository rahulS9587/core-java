package com.java8;

interface sumInter{
	public int sum(int a,int b);
}

public class lambda1 {
	public static void main(String[] args) {
		sumInter inter=  ( a, b)-> a+b;
		
		
		System.out.println(inter.sum(12, 120));
	}

}
