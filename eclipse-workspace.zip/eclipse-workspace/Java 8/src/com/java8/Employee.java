package com.java8;

//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Collections;
//import java.util.Comparator;

public class Employee {
	private String empName;
	private int empID;

	public Employee(String empName, int empID) {
		super();
		this.empName = empName;
		this.empID = empID;
	}

	public String getEmpName() {
		return empName;
	}

	public int getEmpID() {
		return empID;
	}

	@Override
	public String toString() {
		return "Employee [empName=" + empName + ", empID=" + empID + "]";
	}

	public static void main(String[] args) {
//		ArrayList<Employee> emp = new ArrayList<Employee>();
//		emp.addAll(Arrays.asList(new Employee("Rahul", 1), new Employee("Rohit", 12), new Employee("anurag", 34),
//				new Employee("aman", 56), new Employee("santosh", 77)
//
//		));
//		System.out.println(emp);
//	//	Collections.sort(emp, ( e1, e2) -> e1.getEmpName().compareTo(e2.getEmpName()));
//		//or
//		Collections.sort(emp, Comparator.comparing(Employee:: getEmpName));
//		System.out.println(emp);
//		

	}

}
