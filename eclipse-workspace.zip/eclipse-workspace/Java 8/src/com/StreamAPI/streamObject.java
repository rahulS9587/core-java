package com.StreamAPI;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class streamObject {
	public static void main(String[] args) {
		
		// 1-blank
		Stream<Object> emptyStream = Stream.empty();

		//2-array,object,collection
		String names[] = { "aa", "bb", "cc" };

		Stream<String> stream1 = Stream.of(names);
		stream1.forEach(e -> {
			System.out.println(e);
		});
		
		//stream builder
		Stream<Object> streamBuilder = Stream.builder().build();
		
		//
		IntStream stream=Arrays.stream(new int[] {1,2,3,4,5});
		stream.forEach(e->{
			System.out.println(e);
			
		});
		// list,set,collection object...
		List<Integer> list2=new ArrayList<Integer>();
		list2.add(12);
		list2.add(32);
		list2.add(77);
		list2.add(92);
		
		Stream<Integer> st=list2.stream();
		list2.forEach(e->{
			System.out.println(e);
			
		});

		
		
		
		
		
		
		
		
	}

}
