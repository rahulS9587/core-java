package com.StreamAPI;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class methods {
	public static void main(String[] args) {
		
		
		// filter(predicate) it works on boolean
		List<String> name= new ArrayList<String>();
		name.add("Rahul");
		name.add("Anugrah");
		name.add("bajrang");
		name.add("himanshi");
		
		List<String> newName=name.stream().filter(e-> e.startsWith("h")).collect(Collectors.toList());
		System.out.println(newName);
		
		
		
		
		
		// map(Function) it works on element
		List<Integer> in=new ArrayList<Integer>();
		in.add(12);
		in.add(32);
		in.add(77);
		in.add(92);
		List<Integer> newIn=in.stream().map(i->i*i).collect(Collectors.toList());
		System.out.println(newIn);
		
		
		//	for each elements
		name.forEach(e->{
			System.out.println(name);
		});
		
		
		
	

		
	}

}
