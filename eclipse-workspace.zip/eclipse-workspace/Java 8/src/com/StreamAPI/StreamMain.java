package com.StreamAPI;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamMain {
	public static void main(String[] args) {
		
		
		List<Integer> list1=new ArrayList<Integer>();
		list1.add(12);
		list1.add(3);
		list1.add(14);
		list1.add(56);
		list1.add(59);
		System.out.println(list1);
		
		
		// without stream api
		List<Integer> listeven=new ArrayList<Integer>();
		for (Integer i : list1) {
			if(i%2==0) {
				listeven.add(i);
			}
			
		}
		System.out.println(listeven);
		
		
		// same thing using stream api
		
		Stream<Integer> stream=list1.stream();
		List<Integer> newList=stream.filter(i->i%2==0).collect(Collectors.toList());
		System.out.println(newList);
		

	
	}

}
