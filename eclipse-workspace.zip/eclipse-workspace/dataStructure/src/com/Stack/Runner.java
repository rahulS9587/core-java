package com.Stack;

public class Runner {
	public static void main(String[] args) {
		//Stack st=new Stack();
		DStack st=new DStack();
		st.push(12);
		st.show();
		st.push(14);
		st.show();
		st.push(11);
		st.show();

		st.push(1);
		st.show();
		st.pop();
		st.show();
		st.pop();
		st.show();

	//	st.push(15);

	//	st.push(142);

		//st.pop(); 
	//	System.out.println(st.peek());
	//	st.show();
	//	System.out.println("the size is " +st.size());
	//	System.out.println(st.isEmpty());

		
	}

}
