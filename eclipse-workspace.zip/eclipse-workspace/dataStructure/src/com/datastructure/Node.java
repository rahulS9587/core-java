package com.datastructure;

public class Node {
	int data;
	Node next;
	

}
