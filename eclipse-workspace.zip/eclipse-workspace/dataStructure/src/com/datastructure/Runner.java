package com.datastructure;

public class Runner {
	public static void main(String[] args) {
		LinkedList list=new LinkedList();
		list.insert(45);
		list.insert(47);
		list.insert(6);
		list.insertAtStart(12);
		list.insertAt(1,10 );
		list.deleteAt(2);
		list.show();

		
	}

}
