package com.Queue;

public class Runner {
	public static void main(String[] args) {
		Queue q = new Queue();
		q.enQueue(12);
		q.enQueue(23);

		q.enQueue(35);

		q.enQueue(89);
		//q.enQueue(7);

//		q.enQueue(9);

		// q.dequeue();
		// q.show();
		// q.dequeue();
		q.show();
		System.out.println(" ");
		System.out.println("the size of the queue is : ");
		System.out.println(q.getSize());
		System.out.println(q.isEmpty());
		System.out.println(q.isFull());

	}

}
