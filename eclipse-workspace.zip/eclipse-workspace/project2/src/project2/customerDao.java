package project2;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class customerDao {
	
	public static boolean insertCustomerToDB(customer operation) {
		
		boolean f=false;
		try {
			Connection con=connectionProvider.createConnection();
			String q="insert into(Account_num,name,age ,Account_type,salary,balance) values(?,?,?,?,?,?)";
			PreparedStatement pstmt=con.prepareStatement(q);
			pstmt.setLong(1,operation.AccountNum);
			pstmt.setString(2, operation.name);
			pstmt.setInt(3, operation.age);
			pstmt.setString(4, operation.Account_type);
			pstmt.setLong(5, operation.salary);
			pstmt.setLong(6, operation.balance);
			
			pstmt.executeUpdate();
			f=true;

			
			

		}catch(Exception e) {
			e.printStackTrace();
		}
		return f; 
	}

}
