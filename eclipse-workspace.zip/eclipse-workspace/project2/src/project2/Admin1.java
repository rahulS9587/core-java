package project2;
public class Admin1{
	public static void main(String[] args) {
		
	}
}


