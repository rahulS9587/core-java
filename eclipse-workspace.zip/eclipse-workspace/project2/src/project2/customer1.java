package project2;

public class customer1 {
	int acc_no;
	String name;
	String age;
	String acc_type;
	int balance;
	
	public customer1(int acc_no, String name, String age, String acc_type, int balance) {
		super();
		this.acc_no = acc_no;
		this.name = name;
		this.age = age;
		this.acc_type = acc_type;
		this.balance = balance;
	}
	public customer1() {
		super();
		
	}

	@Override
	public String toString() {
		return "customer1 [acc_no=" + acc_no + ", name=" + name + ", age=" + age + ", acc_type=" + acc_type
				+ ", balance=" + balance + "]";
	}
	public int getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(int acc_no) {
		this.acc_no = acc_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getAcc_type() {
		return acc_type;
	}
	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	

}
