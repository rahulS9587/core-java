package project2;

import java.util.ArrayList;
import java.util.Scanner;

public class Bank {

	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		customer customer1 = new customer(123, "rahul", 21, "saving", 2000, 1000, 17000);
		ArrayList<customer> accounts = new ArrayList<customer>();
		accounts.add(customer1);
		customer operation = new customer();
		
		operation.addCustomer();
		
		int choice;
		do {
			System.out.println("\n Banking System Application \n");
			System.out.println("1. show all account details");
			System.out.println("2. Deposit the amount");
			System.out.println("3. withdraw the amount");
			System.out.println("4. transfer funds");
			System.out.println("5. Exit\n ");

			System.out.println("Enter your choice: ");
			choice = in.nextInt();

			switch (choice) {
			case 1:
				for (int i = 0; i < accounts.size(); i++) {
					operation.showCustomer_details();
				}

				break;
			case 2:
				System.out.println("enter the account no, you want to deposite");
				long ac_no = in.nextLong();
				boolean found = false;
				for (int i = 0; i < accounts.size(); i++) {
					found = operation.search(ac_no);
					if (found) {
						operation.Deposite();
						
						break;
					}
				}
				if (!found) {
					System.out.println("Search failed! Account doesn't exist..!!");
				}
				break;
			case 3:
				System.out.println("enter the account no, you want to withdraw");
				ac_no = in.nextLong();
				found = false;
				for (int i = 0; i < accounts.size(); i++) {
					found = operation.search(ac_no);
					if (found) {
						operation.Withdraw();

						break;
					}
				}
				if (!found) {
					System.out.println("Search failed! Account doesn't exist..!!");
				}
				break;
			case 4:
				System.out.println("enter the account no, you want to transfer the funds:");
				ac_no = in.nextLong();
				found = false;
				if (found) {
					operation.TransferFunds();

					break;
				}
				if (!found) {
					System.out.println("Search failed! Account doesn't exist..!!");
				}
				break;
			case 5:
				System.out.println("Thanks for visiting !  See you soon...");
				break;
			}
		} while (choice != 5);

	}
}