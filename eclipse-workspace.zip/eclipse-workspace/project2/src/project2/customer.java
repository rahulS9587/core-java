package project2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

@SuppressWarnings("serial")
class InvalidValueException extends RuntimeException {
	String msg;

	InvalidValueException(String msg) {
		this.msg = msg;
		System.out.println(msg);

	}

}

public class customer {
	Scanner in = new Scanner(System.in);
	long AccountNum;
	String name;
	String email;
	int age;
	String Account_type;
	long balance;
	long amt;
	long salary;
	long fund;

	public customer(long accountNum, String name, int age, String account_type, long balance, long amt, long salary) {
		super();
		AccountNum = accountNum;
		this.name = name;
		this.age = age;
		Account_type = account_type;
		this.balance = balance;
		this.amt = amt;
		this.salary = salary;
	}

	public customer() {

	}

	public void addCustomer() {
		System.out.println("Enter the name of the customer: ");
		name = in.next();
		System.out.println("Enter the account no: ");
		AccountNum = in.nextLong();
		System.out.println("Enter the age of the customer: ");
		age = in.nextInt();

		System.out.println("Enter the Account Type: ");
		Account_type = in.next();

		if (Account_type.compareTo("saving") == 0) {
			System.out.println("Enter your salary: ");
			salary = in.nextLong();
			System.out.println("Enter the minimum balance");
			balance = balance + in.nextLong();
			try {
				if (salary > 15000 && balance > 1000) {
					System.out.println("You are eigible for this saving Account");
					System.out.println("Congratulations ! account opened....");
				} else {
					throw new InvalidValueException("invalid input");

				}

			} catch (InvalidValueException e) {
				System.out.println("Sorry! you are not eligible for this saving account");
				e.printStackTrace();
			}
		}

		if (Account_type.compareTo("current") == 0) {
			System.out.println("Enter your salary: ");
			salary = in.nextLong();
			System.out.println("Enter the minimum balance");
			balance = balance + in.nextLong();
			try {
				if (salary > 50000 && balance > 2000) {
					System.out.println("Congratulations ! Your account is opened ");
				} else {
					throw new InvalidValueException("invalid input");
				}
			} catch (InvalidValueException e) {
				System.out.println("Sorry! you are not eligible for this current account");
				e.printStackTrace();
			}

		}
		// First
		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Register");

			// second

			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "root");

			// third

			PreparedStatement stmt = con.prepareStatement("insert into customer value(?,?,?,?,?,?)");
			stmt.setLong(1, AccountNum);
			stmt.setString(2, name);
			stmt.setInt(3, age);
			stmt.setString(4, Account_type);
			stmt.setLong(5,salary);
			stmt.setLong(6,balance);
			

			int i = stmt.executeUpdate();
			System.out.println(i + "Number of records inserted");

			// fifth

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void Deposite() {
		System.out.println("Enter the amount you want to deposite:");
		amt = in.nextLong();
		balance = balance + amt;
	}

	public void Withdraw() {
		System.out.println("Enter the amount you want to withdrw:");
		amt = in.nextLong();
		if (balance > amt) {
			balance = balance - amt;
			System.out.println("Balance after withdraw: " + balance);
		} else {
			System.out.println("Your balance is less than " + amt + " \n transaction failed!");
		}

	}

	public void TransferFunds() {
		System.out.println("Enter the amount you want to transfer: ");
		fund = in.nextLong();
		if (balance > fund) {
			balance = balance - fund;
			System.out.println("Your balance after transferring is: " + balance);
		} else {
			System.out.println("your amount is not enough to transfer the funds");
		}

	}

	public void showCustomer_details() {
		System.out.println("Name of account holder: " + name);
		System.out.println("Account no.: " + AccountNum);
		System.out.println("The age of  is: " + age);
		System.out.println("Account type: " + Account_type);
		System.out.println("the salary  is: " + salary);
		System.out.println("your balance is: " + balance);
	}

	// }
	public boolean search(long ac_no) {
		if (AccountNum == ac_no) {
			showCustomer_details();
			return (true);
		}
		return (false);
	}

	public static void main(String[] args) {

	}

}
