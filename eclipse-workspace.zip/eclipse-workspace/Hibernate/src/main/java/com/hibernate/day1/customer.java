package com.hibernate.day1;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

@SuppressWarnings("serial")
class InvalidValueException extends RuntimeException {
	String msg;

	InvalidValueException(String msg) {
		this.msg = msg;
		System.out.println(msg);

	}

}

@Entity
public class customer {

	@Id
	long AccountNum;
	String name;
	int age;
	String Account_type;
	long balance;
	@Transient
	long amt;
	long salary;
	@Transient
	long fund;
	@Transient
	long amt1;

	public long getAmt1() {
		return amt1;
	}

	public void setAmt1(long amt1) {
		this.amt1 = amt1;

		if (balance > amt1) {
			balance = balance - amt1;
			System.out.println("Balance after withdraw: " + balance);
		} else {
			System.out.println("Your balance is less than " + amt1 + " \n transaction failed!");
		}

	}

	public customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public customer(long accountNum, String name, int age, String account_type, long balance, long salary) {
		super();
		AccountNum = accountNum;
		this.name = name;
		this.age = age;
		Account_type = account_type;
		this.balance = balance;
		this.salary = salary;
	}

	public long getAccountNum() {
		return AccountNum;
	}

	public void setAccountNum(long accountNum) {
		AccountNum = accountNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setAccount_type(String account_type) {
		Account_type = account_type;
		if (Account_type.compareTo("saving") == 0) {
			try {
				if (salary > 15000 && balance > 1000) {
					System.out.println("You are eigible for this saving Account");
					System.out.println("Congratulations ! account opened....");
				} else {
					throw new InvalidValueException("invalid input");

				}

			} catch (InvalidValueException e) {
				System.out.println("Sorry! you are not eligible for this saving account");
				e.printStackTrace();
			}
		}
		if (Account_type.compareTo("current") == 0) {
			try {
				if (salary > 50000 && balance > 2000) {
					System.out.println("Congratulations ! Your account is opened ");
				} else {
					throw new InvalidValueException("invalid input");
				}
			} catch (InvalidValueException e) {
				System.out.println("Sorry! you are not eligible for this current account");
				e.printStackTrace();
			}
		}

	}

	public String getAccount_type() {
		return Account_type;

	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public long getAmt() {
		return amt;
	}

	public void setAmt(long amt) {
		this.amt = amt;
		balance = balance + amt;
	}

	public void deposite() {
		balance = balance + amt;
	}

	public long getFund() {
		return fund;
	}

	public void setFund(long fund) {
		this.fund = fund;

		if (balance > fund) {
			balance = balance - fund;
			System.out.println("Your balance after transferring is: " + balance);
		} else {
			System.out.println("your amount is not enough to transfer the funds");
		}
	}

	public static void main(String[] args) {

	}

}
