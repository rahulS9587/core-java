package com.hibernate.day1;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="CustomerDetails")
	
public class Customer1 {
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="CustomerId")
	int custid;
	
	
	@Column(name="CustomerName")
	String custname;
	public Customer1() {
	}
	public Customer1(int custid, String custname) {
		this.custid = custid;
		this.custname = custname;
	}
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	@Override
	public String toString() {
		return "Customer [custid=" + custid + ", custname=" + custname + "]";
	}
	
}

	
