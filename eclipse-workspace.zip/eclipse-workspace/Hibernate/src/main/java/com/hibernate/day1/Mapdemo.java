package com.hibernate.day1;

import org.hibernate.cfg.Configuration;


import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Mapdemo {
	public static void main(String[] args) {
		SessionFactory factory= new Configuration().configure().buildSessionFactory();

		question q1=new question();
		q1.setQuestionid(1);
		q1.setQuestion("what is java");
		
		answer a1=new answer();
		a1.setAnswerid(2);
		a1.setAnswer("java is the programming language");
		q1.setAns(a1);
		////////////
		question q2=new question();
		q2.setQuestionid(4);
		q2.setQuestion("what is collection");
		
		answer a2=new answer();
		a2.setAnswerid(3);
		a2.setAnswer("it is a framework ");
		q1.setAns(a2);
		Session session=factory.openSession();
		session.beginTransaction();
		session.save(q1);
		session.save(a1);
		session.save(q2);
		session.save(a2);
		
		
		session.getTransaction().commit();
		
		session.close();
		factory.close();
	}

}
