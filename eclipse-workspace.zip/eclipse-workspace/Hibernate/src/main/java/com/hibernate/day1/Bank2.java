package com.hibernate.day1;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Bank2 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		customer cust = new customer();
		int choice;
		do {
			System.out.println("\n Banking System Application \n");
			System.out.println("1. Open new Account");
			System.out.println("2. show all account details");
			System.out.println("3. Deposit the amount");
			System.out.println("4. withdraw the amount");
			System.out.println("5. transfer funds");
			System.out.println("6. For saving/fetching the data !Exit\n ");
			System.out.println("Enter your choice: ");
			choice = in.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter the name of the customer: ");
				cust.setName(in.next());
				System.out.println("Enter the account no: ");
				cust.setAccountNum(in.nextLong());
				System.out.println("Enter the age of the customer: ");
				cust.setAge(in.nextInt());
				System.out.println("enter the salary");
				cust.setSalary(in.nextLong());
				System.out.println("enter the minimum balance");
				cust.setBalance(in.nextLong());
				System.out.println("Enter the Account Type: ");
				cust.setAccount_type(in.next());

				break;
			case 2:
				System.out.println("The name of the customer is: " + cust.getName());
				System.out.println("Account no.: " + cust.getAccountNum());
				System.out.println("The age of  is: " + cust.getAge());
				System.out.println("Account type: " + cust.getAccount_type());
				System.out.println("the salary  is: " + cust.getSalary());
				System.out.println("your balance is: " + cust.getBalance());

				break;
			case 3:
				System.out.println("Enter the amount you want to deposite");
				long amt = in.nextLong();
				// cust.setAmt(in.nextLong());

				System.out.println("Enter the account number");

				long AccountNum = in.nextLong();

				SessionFactory factory = new Configuration().configure().addAnnotatedClass(customer.class)
						.buildSessionFactory();
				Session session = factory.openSession();

				session.beginTransaction();

				customer cust1 = (customer) session.get(customer.class, AccountNum);
				long balance = cust1.getBalance();

				balance = balance + amt;
				cust1.setBalance(balance);
				session.update(cust1);
				System.out.println("The Balance for Account" + AccountNum + "after deposite is" + balance);

				session.getTransaction().commit();
				session.close();
				factory.close();

				break;

			case 4:
				System.out.println("Enter the amount you want to withdraw");
				long amt1 = in.nextLong();
				// cust.setAmt1(in.nextLong());
				System.out.println("Enter the account number");

				AccountNum = in.nextLong();

				SessionFactory factory1 = new Configuration().configure().addAnnotatedClass(customer.class)
						.buildSessionFactory();
				Session session1 = factory1.openSession();

				session1.beginTransaction();

				customer cust2 = (customer) session1.get(customer.class, AccountNum);
				balance = cust2.getBalance();

				if (balance > amt1) {
					balance = balance - amt1;
					System.out.println("Balance after withdraw: " + balance);
				} else {
					System.out.println("Your balance is less than " + amt1 + " \n transaction failed!");
				}

				cust2.setBalance(balance);
				session1.update(cust2);
				System.out.println("The Balance for Account" + AccountNum + "after withdraw is" + balance);

				session1.getTransaction().commit();
				session1.close();
				factory1.close();

				break;
			case 5:
				System.out.println("Enter the fund you want to transfer");
				// cust.setFund(in.nextLong());
				long fund = in.nextLong();
				System.out.println("Enter the account number");

				AccountNum = in.nextLong();

				SessionFactory factory2 = new Configuration().configure().addAnnotatedClass(customer.class)
						.buildSessionFactory();
				Session session2 = factory2.openSession();

				session2.beginTransaction();

				customer cust3 = (customer) session2.get(customer.class, AccountNum);
				balance = cust3.getBalance();

				if (balance > fund) {
					balance = balance - fund;
					System.out.println("Your balance after transferring is: " + balance);
				} else {
					System.out.println("your amount is not enough to transfer the funds");
				}

				cust3.setBalance(balance);
				session2.update(cust3);
				System.out.println("The Balance for Account" + AccountNum + "after withdraw is" + balance);

				session2.getTransaction().commit();
				session2.close();
				factory2.close();

				break;
			case 6:
				System.out.println("Thanks for visiting !  See you soon...");
				break;
			}
		} while (choice != 6);
		 SessionFactory factory = new
		 Configuration().configure().buildSessionFactory();

		 Session session = factory.openSession();

		 session.beginTransaction();
	//	 session.save(cust);
		 session.getTransaction().commit();
		// HQL Syntax

		 String query = "from customer";
		// for using where
		// String query="from customer where customer_id=2";
		// or for user input
		// String query="from customer where customer_id=:x";

		 Query q = session.createQuery(query);
		// q.setParameter("x", 1);
		// single-(Unique)
		// multiple-list
		 List<customer> list = q.list();
		 for (customer cust1 : list) {
		 System.out.println( cust1.getName() + " : " + cust1.getAccount_type()
		 + " : " + cust1.getAccountNum() + " : " + cust1.getBalance() + " : " +
		 cust1.getSalary());
		 }

		 session.close();
		 factory.close();
	}

}
