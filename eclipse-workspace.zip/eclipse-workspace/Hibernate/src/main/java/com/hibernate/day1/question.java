package com.hibernate.day1;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class question {
	@Id
	@Column(name="question_id")
	int questionid;
	String question;
	@OneToOne
	answer ans;
	public question() {
		super();
		// TODO Auto-generated constructor stub
	}

	public question(int questionid, String question, answer ans) {
		super();
		this.questionid = questionid;
		this.question = question;
		this.ans = ans;
	}

	public answer getAns() {
		return ans;
	}

	public void setAns(answer ans) {
		this.ans = ans;
	}

	public int getQuestionid() {
		return questionid;
	}
	public void setQuestionid(int questionid) {
		this.questionid = questionid;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	

}
