package com.hibernate.day1;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class answer {
	@Id
	@Column(name="answer_id")
	int answerid;
	String answer;
	public int getAnswerid() {
		return answerid;
	}
	public void setAnswerid(int answerid) {
		this.answerid = answerid;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public answer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public answer(int answerid, String answer) {
		super();
		this.answerid = answerid;
		this.answer = answer;
	}
	

}
