package com.hibernate.day1;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name="bank_details")
public class bank1 {
	@Id 
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Cust_name")
	String  cust;
	@Column(name="cust_age")
	int age;
	public bank1(String cust, int age) {
		super();
		this.cust = cust;
		this.age = age;
	}
	public bank1() {
		super();
	}
	public String getCust() {
		return cust;
	}
	public void setCust(String cust) {
		this.cust = cust;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "bank [cust=" + cust + ", age=" + age + "]";
	}
	public static void main(String[] args) {
		
	}


}
