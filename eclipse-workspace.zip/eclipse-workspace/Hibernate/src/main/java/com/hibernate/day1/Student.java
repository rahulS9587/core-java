package com.hibernate.day1;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student_details")
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int studid;
	String studname;
	certificate certi;
	public certificate getCerti() {
		return certi;
	}
	public void setCerti(certificate certi) {
		this.certi = certi;
	}
	public int getStudid() {
		return studid;
	}
	public void setStudid(int studid) {
		this.studid = studid;
	}
	public String getStudname() {
		return studname;
	}
	public void setStudname(String studname) {
		this.studname = studname;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int studid, String studname) {
		super();
		this.studid = studid;
		this.studname = studname;
	}

}
