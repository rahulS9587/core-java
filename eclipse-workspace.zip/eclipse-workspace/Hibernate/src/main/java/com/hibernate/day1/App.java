package com.hibernate.day1;

import javax.transaction.Transaction;

/**
 * Hello world!
 *
 */

	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.cfg.Configuration;
	public class App 
	{

		public static void main(String[] args) {

			SessionFactory factory=new Configuration().configure().buildSessionFactory();
	//		System.out.println(factory);
			
		//	Session session=factory.openSession();
			
		//	session.beginTransaction();
			//Transaction tx=session.getTransaction();
			//tx.begin();
			
			// trasient state 
	/*		Customer cust=new Customer();
			cust.setCustname("Amit");
			
			Customer cust2=new Customer();
			cust2.setCustname("Sumit");
			
			session.persist(cust);
			session.persist(cust2);
			
			session.getTransaction().commit();
			
			Customer cust3=session.get(Customer.class, 1);
			System.out.println(cust3);
			
			

			Customer cust4=session.get(Customer.class, 1);
			System.out.println(cust4);
			
			
			session.evict(cust3);
			
			 session=factory.openSession();
			
			Customer cust5=session.get(Customer.class, 1);
			System.out.println(cust5);*/
		//	bank ban=new bank();
			//ban.setCust("rahul");
		//	ban.setAge(18);
		//	bank ban1=new bank();
		//	ban1.setCust("name");
		//	ban1.setAge(22);
	//		Session session=factory.openSession();
		//	session.beginTransaction();
		//	session.save(ban);
		//	session.save(ban1);
		//	session.getTransaction().commit();
			// get for get we can not  use transaction.
		//	bank ban2=session.get(bank.class, "rahul");
		//	System.out.println(ban2);
			
		//	session.close();
		//	factory.close();
			
		}

}
