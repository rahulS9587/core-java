package com.hibernate.day1;

import javax.persistence.Embeddable;

@Embeddable
public class certificate {
	public certificate() {
		super();
		// TODO Auto-generated constructor stub
	}
	public certificate(String course, int duration) {
		super();
		this.course = course;
		this.duration = duration;
	}

	String course;
	int duration;
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}

}
