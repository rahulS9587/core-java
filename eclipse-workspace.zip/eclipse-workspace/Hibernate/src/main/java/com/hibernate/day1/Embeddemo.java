package com.hibernate.day1;


import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.day1.Student;
import com.hibernate.day1.certificate;

import org.hibernate.Session;



public class Embeddemo {
	public static void main(String[] args) {
		SessionFactory factory=new Configuration().configure().buildSessionFactory();
		Student st=new Student();
		st.setStudname("rahul");
		
		certificate certi1=new certificate();
		certi1.setCourse("android");
		certi1.setDuration(200);
		st.setCerti(certi1);
		Student st1=new Student();
		st1.setStudname("ramu");
		
		certificate certi2=new certificate();
		certi2.setCourse("angular");
		certi2.setDuration(300);
		st1.setCerti(certi2);
		
		Session session= factory.openSession();
		
		session.beginTransaction();
		session.save(st);
		session.save(st1);

		
			session.getTransaction().commit();

		session.close();
		factory.close();
	}

}
