package com.hiber;


import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class question1 {
	@Id
	@Column(name="question_id")
	int questionid;
	String question;
	@OneToMany
	List<answer1> ans;
	public question1() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public question1(int questionid, String question, List<answer1> ans) {
		super();
		this.questionid = questionid;
		this.question = question;
		this.ans = ans;
	}



	public List<answer1> getAns() {
		return ans;
	}



	public void setAns(List<answer1> ans) {
		this.ans = ans;
	}



	public int getQuestionid() {
		return questionid;
	}
	public void setQuestionid(int questionid) {
		this.questionid = questionid;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	

}

