package com.hiber;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class answer1 {
	@Id
	@Column(name="answer_id")
	int answerid;
	String answer;
	@ManyToOne
	question1 ques;
	public question1 getQues() {
		return ques;
	}
	public void setQues(question1 ques) {
		this.ques = ques;
	}
	public int getAnswerid() {
		return answerid;
	}
	public void setAnswerid(int answerid) {
		this.answerid = answerid;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public answer1() {
		super();
		// TODO Auto-generated constructor stub
	}
	public answer1(int answerid, String answer) {
		super();
		this.answerid = answerid;
		this.answer = answer;
	}
	

}

