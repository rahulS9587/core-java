package com.hiber;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.day1.answer;
import com.hibernate.day1.question;

public class one_to_many {
	public static void main(String[] args) {

		SessionFactory factory = new Configuration().configure().buildSessionFactory();

		question1 q1 = new question1();
		q1.setQuestionid(1212);
		q1.setQuestion("what is java");

		answer1 a1 = new answer1();
		a1.setAnswerid(343);
		a1.setAnswer("java is the programming language");
		a1.setQues(q1);
		
		answer1 a2 = new answer1();
		a2.setAnswerid(344);
		a2.setAnswer("java has a oops concept");
		a2.setQues(q1);
		
		answer1 a3 = new answer1();
		a3.setAnswerid(345);
		a3.setAnswer("it has differnt type of frameworks");
		a3.setQues(q1);
		List<answer1> list=new ArrayList<answer1>();
		list.add(a1);
		list.add(a2);

		list.add(a3);
		q1.setAns(list);

		Session session=factory.openSession();
		session.beginTransaction();
	
		session.save(q1);
		
		session.getTransaction().commit();
		
		session.close();
		factory.close();

	}
}
