package com.hibernate.day1;

import javax.security.auth.login.Configuration;

import org.hibernate.SessionFactory;

public class xyz {
	public static void main(String[] args) {
	}

}
