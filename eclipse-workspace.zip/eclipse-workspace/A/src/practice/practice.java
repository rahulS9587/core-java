package practice;
class practice2{
	String name;
	public   synchronized void print(String name){
		this.name=name;
		for(int i=0;i<=10;i++) {
			System.out.println("the name of the project is: " +name + "project number " +i);	
		}	
	}
}
	
public class practice{
	public static void main(String[] args) {
		practice2 t1=new practice2();
		t1.print("java");
		Thread t2=new myThread(t1);
		t2.start();
		Thread t3=new myThread1(t1);
		t3.start();
		
		
				
				
				
		
	
		
	}

}
