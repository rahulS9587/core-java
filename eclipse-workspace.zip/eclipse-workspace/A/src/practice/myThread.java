package practice;

public class myThread extends Thread {
		practice2 prac;
	myThread(practice2 prac){
		this. prac= prac;
	}
	public void run() {
		System.out.println("Hello........");
		prac.print("mohnish");
		
	}
		  public static void main(String[] args) {
			
		}
	}


