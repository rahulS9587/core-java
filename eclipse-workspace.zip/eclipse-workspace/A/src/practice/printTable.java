package practice;

public class printTable {
	int n;
	public synchronized  void Table(int n) {
		this.n=n;
		for(int i=1;i<=10;i++) {
			System.out.printf("%dx%d=%d\n",n,i,n*i);
		}
	}
	public static void main(String[] args) {
		printTable t1=new printTable();
		Table5 t2=new Table5(t1);
		t2.start();
		Table7 t4=new Table7(t1);
		t4.start();

		

		
	}

}
