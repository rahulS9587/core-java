package practice;

public class myThread1 extends Thread {
	practice2 prac;
	myThread1(practice2 prac){
		this.prac=prac;
	}

	public void run() {
		System.out.println("Hii..........");
		prac.print("mahesh");
	}

	public static void main(String[] args) {

	}

}
