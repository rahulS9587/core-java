package practice;

public class Table7 extends Thread {
	printTable print;
	public Table7(printTable print) {
		this.print=print;
	}
	public void run() {
		System.out.println("hello");
		print.Table(7);
	}
	public static void main(String[] args) {
		
	}

}
