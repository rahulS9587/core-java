package practice;

public class Table5 extends Thread {
	printTable print;
	public Table5(printTable print) {
		this.print=print;
	}
	public void run() {
		System.out.println("hello rahul");
	print.Table(5);
	}

	public static void main(String[] args) {
	}
	
	}
	