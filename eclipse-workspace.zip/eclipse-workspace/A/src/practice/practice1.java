package practice;
class Account1{
	private int Account_no;
	private	long balance;
	Account1(int Account_no,int balance){
		this.Account_no=Account_no;
		this.balance=balance;
	}
	public int getAccount_no() {
		return Account_no;
	}
	public long getBalance() {
		return balance;
	}
	public void deposit(int amt) {
		balance=balance+amt;
		System.out.println("deposit is complete:" +Thread.currentThread().getName());
		System.out.println("balance after deposit: " +balance);
		notifyAll();
	}
	public synchronized void withdraw(int amt){
		//20000
		long temp,flag=1;
		while(flag!=0){
			temp=balance;
			if(temp-amt>=1000)
			{
				temp=temp-amt;
				balance=temp;
				
				flag=0;
			}
			else
			{
				
			    try {
			    	System.out.println("Insufficent balance"+Thread.currentThread().getName());
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
		}
		System.out.println("Balance after withdraw  "+ balance);
	}
}


public class practice1 implements Runnable {
	Account1 acc;
	int amt;
	boolean b;
	practice1(Account1 acc,int amt,boolean b){
		this.acc=acc;
		this.amt=amt;
		this.b=b;
	}
	public void run() {
		if(b==true) {
			acc.deposit(amt);
		}else {
			acc.withdraw(amt);
		}
	}
	public static void main(String[] args) {
		final boolean credit=true,debit=false;
		Account1 a1=new Account1(100203,15000);
		
		Runnable father=new practice1(a1,10000,credit);
		Thread thr1=new Thread(father);
		Runnable son =new practice1(a1,20000,debit);
		Thread thr2=new Thread(son);
		thr1.start();
		thr2.start();
		
		try {
			thr1.join();
			thr2.join();
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}
		
		
	}

}
