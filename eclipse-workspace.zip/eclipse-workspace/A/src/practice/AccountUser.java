package practice;
 class Account {
	 private int acc_no;
	 private long balance=0;
	 
	public Account(int acc_no, long balance) {
		this.acc_no = acc_no;
		this.balance = balance;
	}

	public int getAcc_no() {
		return acc_no;
	}

	public long getBalance() {
		return balance;
	}
	public synchronized void deposite(int amt)
	{
		balance=balance+amt;
		System.out.println("Deposit is complete:"+ Thread.currentThread().getName());
		System.out.println("Balance after Deposite  "+balance);
	    notifyAll();// 250000
	}
	public synchronized void withdraw(int amt){
		//20000
		long temp,flag=1;
		while(flag!=0){
			temp=balance;
			if(temp-amt>=1000)
			{
				temp=temp-amt;
				balance=temp;
				
				flag=0;
			}
			else
			{
				
			    try {
			    	System.out.println("Insufficent balance"+Thread.currentThread().getName());
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		System.out.println("Balance after withdraw  "+ balance);
	}
}
	
public class AccountUser implements Runnable{
Account acc;  // has a Relationship
int amt;
boolean b;

public AccountUser(Account acc, int amt, boolean b) {
	this.acc = acc;
	this.amt = amt;
	this.b = b;
}
public void run(){
	  if(b==true)
	  {
		  acc.deposite(amt);
	  }
	  else
	  {
		  acc.withdraw(amt);
	  }
  }
	public static void main(String[] args) {
		 final boolean Credit=true, debit=false;
			Account acc=new Account(100203, 15000);
			
			AccountUser father=new AccountUser(acc, 10000, Credit);
			Thread threadFather=new Thread(father);
			
			
			Runnable son= new AccountUser(acc, 20000, debit);
			Thread sonThread=new Thread(son);
			
			sonThread.start();
			threadFather.start();
			
			try {
				sonThread.join();
				threadFather.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}

	
		
	}


