package Project1;

public class CheckingAccount extends Account {
	  
	public static void main(String[] args) {
		

	}

}
