package Project1;

public class Account {
	long AccountNum;
	String name;
	String email;
	int age;
	long phoneNumber;
	String Address;
	String Account_type;
	long balance;
	static int amt;
	long salary;

	Account(String name, long AccountNum, int age, String Account_type) {
		this.name = name;
		this.AccountNum = AccountNum;
		this.age = age;
		this.Account_type = Account_type;
	}

	Account() {

	}

	public static void main(String[] args) {

	}

}
