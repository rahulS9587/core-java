package Project1;

import java.util.Scanner;

public class CreateAccount extends Account {
	CreateAccount(String name, long AccountNum, int age, String Account_type) {
		this.name = name;
		this.AccountNum = AccountNum;
		this.age = age;
		this.Account_type = Account_type;
	}

	CreateAccount() {
		super();
	}
	public void addCustomer(String name, long AccountNum, int age, String Account_type) {
		this.name = name;
		this.AccountNum = AccountNum;
		this.age = age;
		this.Account_type = Account_type;
	}
	public void showCustomer_details() {
		System.out.println("Name of account holder: " + name);
		System.out.println("Account no.: " + AccountNum);
		System.out.println("The age of the " + name + " is: " + age);
		System.out.println("Account type: " + Account_type);
	
	}
	public void Deposite(int amt) {
	
		balance = balance + amt;
	}

	public int Withdraw(long AccountNum,int amt) {
		if (balance > amt) {
			balance = balance - amt;
			System.out.println("Balance after withdraw: " + balance);
		} else {
			System.out.println("Your balance is less than " + amt + " \n transaction failed!");
		}
		return amt;

	}

	public void TransferFunds(long fund) {
	
		if (balance > fund) {
			balance = balance - fund;
			System.out.println("Your balance after transferring is: " + balance);
		} else {
			System.out.println("your amount is not enough to transfer the funds");
		}

	}



	public static void main(String[] args) {
		   String user_name=null,type;
	        type = null;
	        int balance=0,tmp=0;
	        int withd=0,cb=0;
	int aNumber = 0; 
	aNumber = (int)((Math.random() * 9000)+1000); 

	        CreateAccount user = new CreateAccount("user",0,0,"savings"); 
	    
	            Scanner in = new Scanner(System.in);
	            Scanner strng=new Scanner(System.in);
	            int userChoice;
	            boolean quit = false;

	            do {
	                  System.out.println("1. Create Account");
	                  System.out.println("2. Deposit money");
	                  System.out.println("3. Withdraw money");
	                  System.out.println("4. Check balance");
	                  System.out.println("5. Display Account Details");
	                  System.out.println("0. to quit: \n");
	                  System.out.print("Enter Your Choice : ");
	                  userChoice = in.nextInt();
	                  switch (userChoice) {
	                      
	                  case 1:
	                        System.out.print("Enter your Name : ");
	                        user_name=strng.nextLine(); 
	                        System.out.print("Enter Accout Type : ");
	                        type=in.next();
	                        user.addCustomer(user_name, aNumber,  userChoice, type);  
	                        System.out.println("\nYour Account Details\n");
	                        System.out.println("Dont Forget Account Number\n");                     
	                        user.showCustomer_details();
	                        break;
	                      
	                case 2: 
	                    System.out.print("Enter your account Number : ");
	                    tmp=in.nextInt();
	                 if(tmp==user.AccountNum){
	                 System.out.print("Enter Amount Of Money : ");
	                 balance=in.nextInt();
	                 user.balance=balance;
	                 System.out.println("\t Successfully Deposited.");
	              }                
	                     else
	                    System.out.println("Wrong Accoount Number.");          
	                   break;
	                    
	                  case 3: // withdraw money                      
	                     System.out.print("Enter your account Number : ");
	                      tmp=in.nextInt();
	                      
	                          if(tmp==user.AccountNum){                         
	                             if(user.balance==0)
	                             System.out.print("Your Account is Empty.");
	                             
	                             else{
	                             System.out.print("Enter Amout Of Money : ");   
	                             withd=in.nextInt();  
	                             
	                             if(withd>user.balance){
	                             System.out.print("Enter Valid Amout of Money : ");
	                             withd=in.nextInt();
	                             }
	                             else
	                             cb= user.Withdraw( amt, userChoice);
	                             System.out.println("Your Current Balance : "+cb);   
	                             }
	                          }
	                             else
	                             System.out.println("Wrong Accoount Number.");  
	                        break;
	     
	                  case 4: // check balance 

	                      System.out.print("Enter your Account Number : ");
	                      tmp=in.nextInt();
	                      
	                             if(tmp==user.AccountNum){
	                             System.out.println("Your Current Balance : "+user.balance);
	                             }
	                             else
	                             System.out.println("Wrong Accoount Number.");                         
	                      break;
	                      
	                  case 5: // display all info 
	                          
	                      System.out.print("Enter your Account Number :");
	                      tmp=in.nextInt();                     
	                             if(tmp==user.AccountNum){                               
	                             user.showCustomer_details();                             
	                        }else
	                             System.out.println("Wrong Accoount Number.");
	                             
	                      break;
	                  case 0:
	                        quit = true;
	                        break;
	                  default:
	                        System.out.println("Wrong Choice.");
	                        break;
	                  }
	                  System.out.println("\n");
	            } while (!quit);
	            System.out.println("Thanks !");
	             
	     } 

	}


