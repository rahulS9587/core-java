package Assignments;

public class duplicate_in_array {
	public static void main(String[] args) {
		int arr[]= {1,2,3,4,1,3,45,6,7,8,9};
		System.out.println(" find Duplicate elements in given array: ");
		for(int i=0;i<arr.length;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]==arr[j]) {
					System.out.print(" " +arr[j]);
					
				}
			}
		}

	}

}
