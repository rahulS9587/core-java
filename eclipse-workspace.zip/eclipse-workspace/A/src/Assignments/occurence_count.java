package Assignments;

import java.util.Scanner;

public class occurence_count {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no of elements you want is array: " );
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("The array is: ");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();

		}
		System.out.print("Enter the element of which you want to count number of occurrences:");
		int x = sc.nextInt();
		int count=0;
		for(int i=0;i<n;i++) {
			if(arr[i]==x) {
				count++;
				
			}
		}
		System.out.println("Number of Occurrence of the Element:" + count);

	}

}
