package Assignments;

import java.util.Scanner;

public class practice2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the first number");
		int a=sc.nextInt();
		System.out.println("enter the second number");
		int b=sc.nextInt();
		if(a>0 && b>0) {
			System.out.println("you are in 1 section");
		}
		else if(a>0 && b<0) {
			System.out.println("you are in 2 section");

			
		}
		else if(a<0 && b>0) {
			System.out.println("you are in 3 section");

		}
		else if(a<0 && b<0) {
			System.out.println("you are in 4 section");

		}
		else {
			System.out.println("please inter the valid input");
		}
		
	}

}
