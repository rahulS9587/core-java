package ff;
class Bank{
	 int id;
	 int Accountnumber;
	 String account_type;
	 int opening_balance;
	 
	 Bank(int a,int b){
		 this.id=a;
		 this.Accountnumber=b;
	 }
	 public void display() {
		 System.out.println("The id of the customer is: " +id);
		 System.out.println("The account number of the customer is: " +Accountnumber);
		 
	 }
	
}
class SavingBank extends Bank{
	SavingBank(int a,int b,String c,int d){
		super(a,b);
		this.account_type=c;
		this.opening_balance=d;
	}
	public void display_details() {
		System.out.println("The account type is: " +account_type);
		System.out.println("The account opening balance is: " +opening_balance);
		
	}
	
}
public class Bank_saningBank {
	public static void main(String[] args) {
		
		SavingBank b=new SavingBank(12,1000015456,"saving",10000);
		b.display();
		b.display_details();

	}

}
