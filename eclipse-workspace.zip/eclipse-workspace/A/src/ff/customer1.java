package ff;

public class customer1 {
	String name;
	String l_name;
	int age;
	Address sum;
	customer1(Address sum ){
		this.name=name;
		this.l_name=l_name;
		this.age=age;
		this.sum=sum;
	}
	public String toString() {
		return "name " + name + " l_name " +l_name+ " age " + age+ " address " +sum;
	}

	public static void main(String[] args) {
		customer1 cus=new customer1( new Address() );
		System.out.println(cus.toString());
		
	

	}

}
