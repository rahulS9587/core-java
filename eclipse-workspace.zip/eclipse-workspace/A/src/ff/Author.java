package ff;

public class Author {
	private String name;
	private String email;
	private char gender;
	
	Author(String name,String email,char gender){
		this.name=name;
		this.email=email;
		this.gender=gender;
		System.out.println("i am a parameterized  constructor");
	}
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	public char getGender() {
		return gender;
	}
	public String toString() {
		return "the name of the author is :\n" + getName() + "\n The email of the author is:\n" + getEmail() + " \nThe gender of the author is:\n" + getGender();
	}
	public static void main(String[] args) {
		Author author=new Author("alex","alex@somewhere.com",'M');
		System.out.println(author.toString());
		
	}

}
