package ff;

import java.sql.Date;

//import java.util.Scanner;
 class customer{
	 String name;
	
	 String member_type;
	 boolean member=false;
	 customer( String name){
		 this.name=name;
		 this.member_type=member_type;
		 this.member=member;
		 
	 }
	
	 public String getName() {
		 return name;
	 }
	 public boolean isMember() {
		 if(member==false) {
			 return false;
		 }else { 
		 }
		return true;	
	 }
	 void setMember(boolean member) {
		 this.member=member;
	 }
	 boolean getMember() {
		 return member;
	 }
	 
	
	 
	 public void setMember_type(String member_type) {
		 this.member_type=member_type;
		 
	 }
	 public String getMember_type() {
		 return member_type;
	 }
	 
	 
	@Override
	public String toString() {
		return "customer name is: " + name + "\nmember_type is: " + member_type + "\nmember is: " + member ;
	}

	public static void main(String[] args)   {


		
	}	
	
	}
	
		
	
