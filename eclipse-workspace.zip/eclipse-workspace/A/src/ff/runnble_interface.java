package ff;
 class myRunnableThread implements Runnable{

	public void run() {
		for(int i=0;i<=5;i++) {
			System.out.println("thread : " +i);
		}
		
	}
	
	
}
 class myRunnableThread1 implements Runnable{

	@Override
	public void run() {
	for(int i=5;i<=10;i++) {
		System.out.println("my thread : " +i);
		
	}
		
	}
	 
 }
public class runnble_interface {
	public static void main(String[] args) {
		myRunnableThread t1=new myRunnableThread();
		Thread thr=new Thread(t1);
		thr.start();
		
		myRunnableThread1 t2=new myRunnableThread1();
		Thread thr1=new Thread(t2);
		thr1.start();
		
		
		
		
	}

}
