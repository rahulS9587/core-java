package ff;
	

public class circle {
	private double radius;
	private String color;
	private double area;
	circle(double r){
		this.radius=r;
		System.out.println("i am a constructor");
	}
	circle(double r,String c){
	this.color=c;
	System.out.println("i am overloaded constructor");
	}
	public void setRadius(double r) {
		this.radius=r;
	}
	public  double getRadius() {
		return radius;
	}
	public void setArea() {
		area=Math.PI*radius*radius;
		
	}
	public  double getArea() {
		return area;
	}

	public static void main(String[] args) {
		circle c=new circle(1.0);
		c.setRadius(1.0);
		c.setArea();
		System.out.println("the radius of the circle is: " +c.getRadius());
		System.out.println("the area of the circle is: " +c.getArea());
	

	}

}
