package ff;
 
public class try_catch{
	public void sendMsg() throws Exception
	{    int b=20;
		 int a;
		 a=b/0;
	}
	
	public void sendVideo() 
	{
		try {
			sendMsg();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void sendData() 
	{
		sendVideo();
		System.out.println("handled");
	}
	

	public static void main(String[]args) {
		//aa a=new aa();
	//	a.sendMsg();
	

}
}
	
		
		
	
	
	


