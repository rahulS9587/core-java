package ff;


public class stringBuffer_stringBuilder {
	interface aa{
		public void add();
		abstract void sum();
	}
	 
	

	public static void main(String[] args) {
		
	String str="rahul";
	String str1="rahul";
	String str2="Rahul";
	String str3="rahul";
	String str4="rahul";
	
	String str7= new String("rahul");
	String str5= new String("rahul");
	String str6= new String("rahul");
	System.out.println( str==str7); 
	
	
	
	
	StringBuffer buffer=new StringBuffer("Rahul ");
	System.out.println(buffer.append("singh"));
	
	StringBuilder builder=new StringBuilder("Rahul");
	System.out.println(builder.append("singh"));
	}
}

	
		
		
		

	

