package ff;

public class discountRate {
	double serviceDiscountPremium=0.2;
	double serviceDiscountGold=0.15;
	double serviceDiscountSilver=0.1;
	double productDiscountPremium=0.1;
	double productDiscountGold=0.1;
	double productDiscountSilver=0.1;
	
	
	public double getServiceDiscountRate(String Type) {
		if(Type=="premium"){
			return serviceDiscountPremium;
		}else if(Type=="gold") {
			return serviceDiscountGold;
		}else if(Type=="silver") {
			return serviceDiscountSilver;
		}else {
			return 0;
		}
	}
	
	public double getProductDiscountRate(String Type) {
		if(Type=="premium"){
			return productDiscountPremium;
		}else if(Type=="gold") {
			return productDiscountGold;
		}else if(Type=="silver") {
			return productDiscountSilver;
		}else {
			return 0;
		}
	}
	
	public static void main(String[] args) {
		
	}

}
