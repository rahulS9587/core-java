package ff;

public class Address {
	String address;
	int house_no;
	Address(){
		this.address=address;
		this.house_no=house_no;
		
	}
	public String toString() {
		return "address " +address + " house no " + house_no;
	}
	public static void main(String[] args) {
		
	}

}
