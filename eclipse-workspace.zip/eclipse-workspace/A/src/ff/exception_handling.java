package ff;
import java.util.Scanner;
public class exception_handling {
	static int a;
	static int b;
	public static int divide() throws ArithmeticException {
		return a/b;
		
	}
	
	public static void main(String[] args)  {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		 a=sc.nextInt();
		System.out.println("enter the number");
		 b=sc.nextInt();
		 try {
			 int c=divide();
			 System.out.println("the result is " +c);
			// try {
				 
		//	 }catch(Exception e) {
				 
		//	 }
		 }catch(ArithmeticException e) {
			 System.out.println("error");
			 System.out.println(e);
	//	 }catch(Exception e) {
		//	 System.out.println("error");
			// System.out.println(e);

		 }finally {
			 System.out.println("finally");
			 
		 }
		
	
	}
}
	


