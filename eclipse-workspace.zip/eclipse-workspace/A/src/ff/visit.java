package ff;

import java.sql.Date;

public class visit {
	 customer cust;
	 double serviceExpense;
	 double productExpense;
//	 double TotalExpense;
	 Date visitdate;
	 visit(customer cust,Date visitdate){
		 this.cust = cust;
		 this.visitdate=visitdate;
		 
	 }
	 public void setProductExpense(double productExpense) {
		 this.productExpense=productExpense;
	 }
	 double getProductExpense() {
		 return productExpense;
	 }
	 public void setServiceExpense(double serviceExpense) {
		 this.serviceExpense=serviceExpense;
	 }
	 double getServiceExpense() {
		 return serviceExpense;
	 }
	 double getTotalExpense() {
		 discountRate d1 =new discountRate();
		 return (productExpense-productExpense*d1.getProductDiscountRate(cust.getMember_type()))
				 +(serviceExpense-serviceExpense*d1.getServiceDiscountRate(cust.getMember_type()));
	 }
	
	 @Override
		public String toString() {
			return  "\nserviceExpense is: " + serviceExpense + "\nproductExpense is: " + productExpense
					+ "\nvisitdate is: " + visitdate + "\nTotalExpense is: "
					+ getTotalExpense() ;
		}
	 
	public static void main(String[] args) {
		customer t1=new customer("Rahul");
		t1.setMember_type("gold");
		t1.setMember(true);
		customer t2=new customer("Rohit");
		t2.setMember_type("premium");
		t2.setMember(false);
		visit v=new visit(t1,new Date(800000));
		v.setProductExpense(40000);
		v.setServiceExpense(340000);
		System.out.println(t1.toString());
		System.out.println(t2.toString());
		System.out.println(v.toString());
		
	}
	

}
