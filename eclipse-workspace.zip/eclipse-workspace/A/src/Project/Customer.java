package Project;

@SuppressWarnings("serial")
class InvalidValueException extends RuntimeException {
	String msg;

	InvalidValueException(String msg) {
		this.msg = msg;
		System.out.println(msg);

	}

}

public class Customer{
	long AccountNum;
	String name;
	String email;
	int age;
	 String Account_type;
	long balance;
	long amt;
	long salary;
	long fund;
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(long AccountNum, String name, String email, int age, String Account_type, long balance,
			long salary ) {
		super();
		this.AccountNum = AccountNum;
		this.name = name;
		this.email = email;
		this.age = age;
		this.Account_type = Account_type;
		this.balance = balance;
		this.salary = salary;
	}

	public long getAccountNum() {
		return AccountNum;
	}

	public void setAccountNum(long accountNum) {
		AccountNum = accountNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAccount_type() {
		return Account_type;
	}

	public void setAccount_type(String account_type) {
		
		this.Account_type = account_type;
		
	}
		
	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	public long getAmt() {
		return amt;
	}

	public void setAmt(long amt) {
		this.amt = amt;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public long getFund() {
		return fund;
	}

	public void setFund(long fund) {
		this.fund = fund;
	}
	
	
	
}