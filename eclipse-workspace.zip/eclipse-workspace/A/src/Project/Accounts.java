package Project;

import java.util.Scanner;

public class Accounts implements BankApplication{
	static long balance;
	static long amt;
	static long AccountNumber;
	Scanner sc = new Scanner(System.in);
	Customer cust;

	public void Deposite() {
		System.out.println("Enter the account Number: ");
		 AccountNumber = sc.nextInt();
		
		for (Customer customer : Bank.cust) {
			if (customer.getAccountNum() == AccountNumber) {
				System.out.println("Enter the amount you want to deposite:");
				amt = sc.nextLong();
				balance = customer.getBalance() + amt;
				System.out.println("balance after the deposite is:" + balance);

			}else {
				System.out.println("=====Account does not exist !=======");
			}

		}
	}

	public void Withdraw() {

		System.out.println("Enter the account number");
		 AccountNumber = sc.nextLong();

		
		for (Customer customer : Bank.cust) {
			if (customer.getAccountNum() == AccountNumber) {
				System.out.println("Enter the amount you want to withdrw:");
				 amt = sc.nextLong();
				if (balance > amt) {
					balance = balance - amt;
					System.out.println("Balance after withdraw: " + balance);
				} else {
					System.out.println("Your balance is less than " + amt + " \n transaction failed!");
				}

			}else {
				System.out.println("==== Account dose not exist ! ====");

				
			}
		}
	}

	public void TransferFunds() {
		System.out.println("Enter the account number: ");
		 AccountNumber = sc.nextLong();
		for (Customer customer : Bank.cust) {
			if (customer.getAccountNum() == AccountNumber) {
				System.out.println("Enter the amount you want to transfer: ");
				amt = sc.nextLong();
			} else {
				System.out.println("==== Account dose not exist ! ====");
			}
			if (balance > amt) {
				balance = balance - amt;
				System.out.println("Your balance after transferring is: " + balance);
			} else {
				System.out.println("your amount is not enough to transfer the funds");
			}
		}
	}

}
