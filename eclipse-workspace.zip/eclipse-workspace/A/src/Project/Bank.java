package Project;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Bank extends Accounts{
	Scanner sc = new Scanner(System.in);
	static List<Customer> cust = new ArrayList<Customer>();

	public void addCustomer(Customer customer) {
		cust.add(customer);
	}
	public  static Customer addCustomer() {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter account number");
		long AccountNum = sc.nextLong();
		
		
		System.out.print("Enter name of the Customer ");
		 String name = sc.next();

		System.out.print("Enter email: ");
		String email = sc.next();

		System.out.print("Enter your age ");
		int age = sc.nextInt();
		System.out.println("Enter your salary ");
		long salary = sc.nextLong();

		System.out.println("Enter your  balance ");
		long balance = sc.nextLong();
		
		

		System.out.println("Enter your account type  Saving  or Current");
		String Account_type = sc.next();
		if (Account_type.compareTo("saving") == 0) {
			try {
				if (salary > 15000 && balance > 1000) {
					System.out.println("You are eigible for this saving Account");
					System.out.println("Congratulations ! account opened....");
				} else {
					throw new InvalidValueException("invalid input");

				}

			} catch (InvalidValueException e) {
				System.out.println("Sorry! you are not eligible for this saving account");
				e.printStackTrace();
			}
		}
		if (Account_type.compareTo("current") == 0) {
			try {
				if (salary > 50000 && balance > 2000) {
					System.out.println("Congratulations ! Your account is opened ");
				} else {
					throw new InvalidValueException("invalid input");
				}
			} catch (InvalidValueException e) {
				System.out.println("Sorry! you are not eligible for this current account");
				e.printStackTrace();
			}
		}


		Customer newcustomer = new Customer(AccountNum, name, email, age, Account_type, balance, salary);

		return newcustomer;

	}


	public void showCustomer() {
		
		  for (Customer customer : cust) {
		  System.out.println("The name of the customer is: " + customer.getName());
		  System.out.println("Account no.: " + customer.getAccountNum());
		  System.out.println("The age of  is: " + customer.getAge());
		  System.out.println("the salary  is: " + customer.getSalary());
		  System.out.println("your balance is: " + (customer.getBalance()+amt));
		  System.out.println("Account type: " + customer.getAccount_type());
		  
		  }
		 
	}

	
	public static void main(String[] args) {
		
	Scanner sc=new Scanner(System.in);
		Bank bank=new Bank();
		Accounts account=new Accounts();
		int choice;
		do {
			System.out.println("\n Banking System Application \n");
			System.out.println("1. Open new Account");
			System.out.println("2. show all account details");
			System.out.println("3. Deposit the amount");
			System.out.println("4. withdraw the amount");
			System.out.println("5. transfer funds");
			System.out.println("6. For saving/fetching the data !Exit\n ");
			System.out.println("Enter your choice: ");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				Customer customer=Bank.addCustomer();
				bank.addCustomer(customer);
				break;
				
			case 2:
				bank.showCustomer();
				break;
				
			case 3:
				account.Deposite();
				break;
				
			case 4:

				account.Withdraw();
				break;
				
			case 5:
				account.TransferFunds();
				break;
				
			case 6:
				
				System.out.println("Thanks for visiting !  See you soon...");
				break;
				
	}

		}while(choice!=6);
	}
}
	
