package Project;

public interface BankApplication {
	public void Deposite();
	public void Withdraw();
	public void TransferFunds();

}
